var isBipartite = function (graph) {
    let red = []
    let arr = [] 
    let handleArr = []
    let bHasAddEntity = false;
    for (let i = 0; i < graph.length; i++) {
        if (graph[i].length > 0) {
            if (!bHasAddEntity) {
                bHasAddEntity = true;
                red.push(i);
                arr.push(i);
            }
        } else {
            handleArr.push(i)
        }
    }
    while (arr.length) {
        let id = arr.pop()
        handleArr.push(id)
        for (let gInd of graph[id]) {
            if (handleArr.indexOf(gInd) == -1) {
                handleArr.push(gInd)
            }
            if (red.indexOf(gInd) != -1) {
                return false;
            } else {
                for (let rInd of graph[gInd]) {
                    if (red.indexOf(rInd) == -1) {
                        arr.push(rInd)
                        red.push(rInd)
                    }

                }
            }
        }
        if (arr.length == 0) {
            for (let i = 0; i < graph.length; i++) {
                if (handleArr.indexOf(i) == -1) {
                    arr.push(i);
                    break;
                }
            }
        }
    }
    return true;

};
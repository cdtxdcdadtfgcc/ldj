/**
 * @param {number[]} heights
 * @return {number}
 */
var largestRectangleArea = function(heights) {
    let maxArea = 0; 
    const stack = [-1]; 

    for (let i = 0; i <= heights.length; i++) {
       
        const currentHeight = (i === heights.length) ? -1 : heights[i];


        while (stack.length > 1 && heights[stack[stack.length - 1]] > currentHeight) {
            const h = heights[stack.pop()]; 
            const w = i - stack[stack.length - 1] - 1; 
            maxArea = Math.max(maxArea, h * w); 
        }

        stack.push(i); 
    }

    return maxArea;
};